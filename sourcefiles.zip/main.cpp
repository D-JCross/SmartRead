
#include <QApplication>
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    app.setApplicationName("SmartRead");
    app.setApplicationVersion("1.2");
    app.setOrganizationName("SmartRead");

    MainWindow window;
    window.show();

    return app.exec();
}
