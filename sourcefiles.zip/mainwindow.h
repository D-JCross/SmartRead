
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <QStringList>
#include <QVector>
#include <QtGlobal>

class QPdfDocument;
class QTextToSpeech;
class QComboBox;
class QLabel;
class QSlider;
class QSpinBox;
class PdfCanvas;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

private:
    struct NarrationPage {
        QString text;
        QVector<int> sourcePositions;
    };

    QPdfDocument *document = nullptr;
    QTextToSpeech *speech = nullptr;
    PdfCanvas *pdfCanvas = nullptr;

    QComboBox *modeBox = nullptr;
    QLabel *statusLabel = nullptr;
    QLabel *wordLabel = nullptr;
    QLabel *pageLabel = nullptr;
    QLabel *speedLabel = nullptr;
    QSlider *speedSlider = nullptr;
    QSpinBox *pageSelector = nullptr;

    QVector<QString> pages;
    QVector<QStringList> pageLines;
    QVector<NarrationPage> narration;

    int startPage = 0;
    int startOffset = 0;
    int currentPage = -1;
    int nextPage = 0;
    int speechOffset = 0;

    bool playing = false;
    bool stopping = false;
    bool trackingAvailable = false;

    quint64 sessionId = 0;
    qsizetype activeUtteranceId = -1;

    void openPdf();
    void analyzeDocument();
    int detectStoryStart() const;
    NarrationPage buildNarrationPage(int page) const;
    void rebuildNarration();

    void play();
    void pause();
    void resume();
    void stop();
    void speakNextPage();

    void startFromWord(int page, int sourcePosition);
    void spokenWord(
        const QString &word,
        qsizetype start,
        qsizetype length
        );

    void goToPage(int page);
    void updateStatus(const QString &message);
};

#endif
