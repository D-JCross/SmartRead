
#include "mainwindow.h"

#include <QPdfDocument>
#include <QPdfSelection>
#include <QTextToSpeech>
#include <QAbstractScrollArea>
#include <QScrollBar>
#include <QPropertyAnimation>
#include <QEasingCurve>
#include <QPainter>
#include <QMouseEvent>
#include <QResizeEvent>
#include <QImage>
#include <QHash>
#include <QFrame>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QComboBox>
#include <QLabel>
#include <QSlider>
#include <QSpinBox>
#include <QFileDialog>
#include <QMessageBox>
#include <QFileInfo>
#include <QRegularExpression>
#include <QSignalBlocker>
#include <QTimer>
#include <QColor>

#include <algorithm>
#include <functional>
#include <cmath>

// =====================================================
// TEXT HELPERS
// =====================================================

namespace {

bool wordChar(QChar c)
{
    return c.isLetterOrNumber()
    || c == QChar('\'')
        || c == QChar(0x2019)
        || c == QChar('-');
}

int wordStart(const QString &text, int pos)
{
    if (text.isEmpty())
        return -1;

    pos = std::clamp(pos, 0, int(text.size()) - 1);

    while (pos < text.size() && !wordChar(text[pos]))
        ++pos;

    if (pos == text.size())
        return -1;

    while (pos > 0 && wordChar(text[pos - 1]))
        --pos;

    return pos;
}

int wordEnd(const QString &text, int pos)
{
    while (pos < text.size()
           && pos >= 0
           && wordChar(text[pos])) {
        ++pos;
    }

    return pos;
}

}

// =====================================================
// PDF VIEWER
// =====================================================

class PdfCanvas : public QAbstractScrollArea
{
public:
    explicit PdfCanvas(QWidget *parent = nullptr)
        : QAbstractScrollArea(parent)
    {
        setFrameShape(QFrame::NoFrame);
        viewport()->setCursor(Qt::ArrowCursor);

        scrollAnimation = new QPropertyAnimation(
            verticalScrollBar(), "value", this
            );

        scrollAnimation->setDuration(260);
        scrollAnimation->setEasingCurve(
            QEasingCurve::InOutCubic
            );
    }

    std::function<void(int, int)> onWordClicked;
    std::function<void(int)> onPageChanged;

    void setPdf(QPdfDocument *pdf)
    {
        scrollAnimation->stop();
        document = pdf;
        cachedImages.clear();
        clearHighlight();
        rebuildLayout();
        verticalScrollBar()->setValue(0);
        viewport()->update();
    }

    void clearHighlight()
    {
        highlightPage = -1;
        highlightStart = -1;
        highlightLength = 0;
        highlightRectangle = QRectF();
        viewport()->update();
    }

    void setHighlight(int page, int start, int length)
    {
        if (!document
            || page < 0
            || page >= document->pageCount()
            || start < 0
            || length <= 0) {

            clearHighlight();
            return;
        }

        if (page == highlightPage
            && start == highlightStart
            && length == highlightLength) {
            return;
        }

        const QPdfSelection selection =
            document->getSelectionAtIndex(
                page, start, length
                );

        if (!selection.isValid()
            || selection.boundingRectangle().isEmpty()) {
            clearHighlight();
            return;
        }

        highlightPage = page;
        highlightStart = start;
        highlightLength = length;
        highlightRectangle = selection.boundingRectangle();

        followRectangle(
            mapPdfRectangle(page, highlightRectangle)
            );

        viewport()->update();
    }

    void goToPage(int page)
    {
        if (page < 0 || page >= pageRects.size())
            return;

        scrollAnimation->stop();

        verticalScrollBar()->setValue(
            int(pageRects[page].top())
            );

        if (onPageChanged)
            onPageChanged(page);

        viewport()->update();
    }

protected:
    void resizeEvent(QResizeEvent *event) override
    {
        QAbstractScrollArea::resizeEvent(event);
        rebuildLayout();
    }

    void scrollContentsBy(int dx, int dy) override
    {
        Q_UNUSED(dx);
        Q_UNUSED(dy);

        viewport()->update();

        if (onPageChanged) {
            const int page = pageAtScrollPosition();

            if (page >= 0)
                onPageChanged(page);
        }
    }

    void paintEvent(QPaintEvent *event) override
    {
        Q_UNUSED(event);

        QPainter painter(viewport());

        painter.setRenderHint(QPainter::Antialiasing);
        painter.setRenderHint(
            QPainter::SmoothPixmapTransform
            );

        painter.fillRect(
            viewport()->rect(),
            QColor("#303239")
            );

        if (!document)
            return;

        const QPointF scroll(
            horizontalScrollBar()->value(),
            verticalScrollBar()->value()
            );

        const QRectF visible(
            scroll,
            QSizeF(viewport()->size())
            );

        for (int page = 0;
             page < pageRects.size();
             ++page) {

            const QRectF content = pageRects[page];

            if (!content.intersects(visible))
                continue;

            const QRectF screen =
                content.translated(-scroll);

            painter.fillRect(
                screen.translated(3, 4),
                QColor(0, 0, 0, 75)
                );

            painter.fillRect(screen, Qt::white);

            const QImage image = pageImage(page);

            if (!image.isNull())
                painter.drawImage(screen, image);

            if (page == highlightPage
                && !highlightRectangle.isEmpty()) {

                QRectF rect =
                    mapPdfRectangle(
                        page, highlightRectangle
                        ).translated(-scroll);

                rect.adjust(-1.5, -1.0, 1.5, 1.0);

                painter.save();
                painter.setPen(Qt::NoPen);
                painter.setBrush(
                    QColor(255, 195, 0, 110)
                    );
                painter.drawRoundedRect(rect, 2, 2);
                painter.restore();
            }
        }
    }

    void mousePressEvent(QMouseEvent *event) override
    {
        if (!document
            || event->button() != Qt::LeftButton) {
            return;
        }

        const QPointF contentPoint =
            event->position()
            + QPointF(
                horizontalScrollBar()->value(),
                verticalScrollBar()->value()
                );

        int page = -1;

        for (int i = 0; i < pageRects.size(); ++i) {
            if (pageRects[i].contains(contentPoint)) {
                page = i;
                break;
            }
        }

        if (page < 0)
            return;

        const QSizeF pdfSize =
            document->pagePointSize(page);

        const QRectF rect = pageRects[page];

        if (pdfSize.isEmpty() || rect.isEmpty())
            return;

        const QPointF pdfPoint(
            (contentPoint.x() - rect.left())
                * pdfSize.width() / rect.width(),
            (contentPoint.y() - rect.top())
                * pdfSize.height() / rect.height()
            );

        int selectedIndex = -1;

        for (const qreal radius : {3.0, 6.0, 11.0}) {
            const QPdfSelection selection =
                document->getSelection(
                    page,
                    QPointF(
                        pdfPoint.x() - radius,
                        pdfPoint.y()
                        ),
                    QPointF(
                        pdfPoint.x() + radius,
                        pdfPoint.y()
                        )
                    );

            if (selection.isValid()
                && !selection.text().trimmed().isEmpty()) {

                selectedIndex = selection.startIndex();
                break;
            }
        }

        if (selectedIndex < 0)
            return;

        const QString text =
            document->getAllText(page).text();

        if (selectedIndex >= text.size())
            return;

        const int beginning =
            wordStart(text, selectedIndex);

        if (beginning >= 0 && onWordClicked)
            onWordClicked(page, beginning);
    }

private:
    QPdfDocument *document = nullptr;

    QVector<QRectF> pageRects;
    QHash<int, QImage> cachedImages;

    QPropertyAnimation *scrollAnimation = nullptr;

    int highlightPage = -1;
    int highlightStart = -1;
    int highlightLength = 0;

    QRectF highlightRectangle;

    QImage pageImage(int page)
    {
        if (cachedImages.contains(page))
            return cachedImages.value(page);

        if (!document
            || page < 0
            || page >= pageRects.size()) {
            return {};
        }

        const QRectF rect = pageRects[page];

        const QSize size(
            std::max(1, int(std::ceil(rect.width()))),
            std::max(1, int(std::ceil(rect.height())))
            );

        const QImage raw =
            document->render(page, size);

        if (raw.isNull())
            return {};

        QImage opaque(size, QImage::Format_RGB32);
        opaque.fill(Qt::white);

        {
            QPainter painter(&opaque);
            painter.drawImage(0, 0, raw);
        }

        if (cachedImages.size() >= 4) {
            int farthest = -1;
            int distance = -1;

            for (auto it = cachedImages.cbegin();
                 it != cachedImages.cend();
                 ++it) {

                if (std::abs(it.key() - page) > distance) {
                    distance = std::abs(it.key() - page);
                    farthest = it.key();
                }
            }

            if (farthest >= 0)
                cachedImages.remove(farthest);
        }

        cachedImages.insert(page, opaque);

        return opaque;
    }

    void rebuildLayout()
    {
        pageRects.clear();
        cachedImages.clear();

        if (!document
            || document->pageCount() <= 0) {

            verticalScrollBar()->setRange(0, 0);
            viewport()->update();
            return;
        }

        const qreal margin = 18;
        const qreal gap = 16;

        const qreal width =
            std::max(
                100.0,
                qreal(viewport()->width()) - margin * 2
                );

        qreal y = margin;

        for (int page = 0;
             page < document->pageCount();
             ++page) {

            QSizeF size =
                document->pagePointSize(page);

            if (size.isEmpty())
                size = QSizeF(612, 792);

            const qreal height =
                width * size.height() / size.width();

            pageRects.append(
                QRectF(margin, y, width, height)
                );

            y += height + gap;
        }

        verticalScrollBar()->setPageStep(
            viewport()->height()
            );

        verticalScrollBar()->setRange(
            0,
            std::max(
                0,
                int(std::ceil(y)) - viewport()->height()
                )
            );

        horizontalScrollBar()->setRange(0, 0);
        viewport()->update();
    }

    QRectF mapPdfRectangle(
        int page,
        const QRectF &pdfRect
        ) const
    {
        if (!document
            || page < 0
            || page >= pageRects.size()) {
            return {};
        }

        const QSizeF size =
            document->pagePointSize(page);

        if (size.isEmpty())
            return {};

        const QRectF rect = pageRects[page];

        const qreal sx =
            rect.width() / size.width();

        const qreal sy =
            rect.height() / size.height();

        return QRectF(
            rect.left() + pdfRect.x() * sx,
            rect.top() + pdfRect.y() * sy,
            pdfRect.width() * sx,
            pdfRect.height() * sy
            );
    }

    int pageAtScrollPosition() const
    {
        if (pageRects.isEmpty())
            return -1;

        const qreal pos =
            verticalScrollBar()->value()
            + viewport()->height() * 0.35;

        for (int i = 0; i < pageRects.size(); ++i) {
            if (pageRects[i].bottom() >= pos)
                return i;
        }

        return pageRects.size() - 1;
    }

    void followRectangle(const QRectF &rect)
    {
        if (rect.isEmpty())
            return;

        const int scroll =
            verticalScrollBar()->value();

        const int height =
            viewport()->height();

        const qreal y =
            rect.center().y() - scroll;

        if (y >= height * 0.25
            && y <= height * 0.63) {
            return;
        }

        const int target = std::clamp(
            int(rect.center().y() - height * 0.43),
            verticalScrollBar()->minimum(),
            verticalScrollBar()->maximum()
            );

        if (std::abs(target - scroll) < 6)
            return;

        scrollAnimation->stop();
        scrollAnimation->setStartValue(scroll);
        scrollAnimation->setEndValue(target);
        scrollAnimation->start();
    }
};

// =====================================================
// MAIN WINDOW
// =====================================================

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setWindowTitle("SmartRead - PDF Audiobook Reader");
    resize(1050, 830);

    document = new QPdfDocument(this);
    speech = new QTextToSpeech(this);

    trackingAvailable =
        speech->engineCapabilities().testFlag(
            QTextToSpeech::Capability::WordByWordProgress
            );

    QWidget *central = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(central);

    layout->setContentsMargins(10, 10, 10, 10);
    layout->setSpacing(9);

    QHBoxLayout *top = new QHBoxLayout;

    QPushButton *openButton =
        new QPushButton("Open PDF");

    modeBox = new QComboBox;
    modeBox->addItems({
        "Story Mode",
        "Read Everything"
    });

    QPushButton *startHereButton =
        new QPushButton("Start From This Page");

    top->addWidget(openButton);
    top->addWidget(new QLabel("Mode:"));
    top->addWidget(modeBox);
    top->addWidget(startHereButton);
    top->addStretch();

    layout->addLayout(top);

    pdfCanvas = new PdfCanvas;
    pdfCanvas->setPdf(document);

    layout->addWidget(pdfCanvas, 1);

    QHBoxLayout *navigation = new QHBoxLayout;

    QPushButton *previous =
        new QPushButton("Previous");

    QPushButton *next =
        new QPushButton("Next");

    pageSelector = new QSpinBox;
    pageSelector->setRange(1, 1);

    pageLabel = new QLabel("No PDF loaded");

    navigation->addWidget(previous);
    navigation->addWidget(pageSelector);
    navigation->addWidget(pageLabel);
    navigation->addWidget(next);
    navigation->addStretch();

    layout->addLayout(navigation);

    QHBoxLayout *controls = new QHBoxLayout;

    QPushButton *playButton =
        new QPushButton("Play");

    QPushButton *pauseButton =
        new QPushButton("Pause");

    QPushButton *resumeButton =
        new QPushButton("Resume");

    QPushButton *stopButton =
        new QPushButton("Stop");

    controls->addWidget(playButton);
    controls->addWidget(pauseButton);
    controls->addWidget(resumeButton);
    controls->addWidget(stopButton);

    layout->addLayout(controls);

    QHBoxLayout *speedRow = new QHBoxLayout;

    speedSlider = new QSlider(Qt::Horizontal);
    speedSlider->setRange(-10, 10);
    speedSlider->setValue(0);

    speedLabel = new QLabel("Normal");

    speedRow->addWidget(new QLabel("Speed:"));
    speedRow->addWidget(speedSlider);
    speedRow->addWidget(speedLabel);

    layout->addLayout(speedRow);

    wordLabel = new QLabel("Current word: --");
    statusLabel = new QLabel("Open a PDF to begin.");

    layout->addWidget(wordLabel);
    layout->addWidget(statusLabel);

    setCentralWidget(central);

    connect(
        openButton,
        &QPushButton::clicked,
        this,
        &MainWindow::openPdf
        );

    connect(
        playButton,
        &QPushButton::clicked,
        this,
        &MainWindow::play
        );

    connect(
        pauseButton,
        &QPushButton::clicked,
        this,
        &MainWindow::pause
        );

    connect(
        resumeButton,
        &QPushButton::clicked,
        this,
        &MainWindow::resume
        );

    connect(
        stopButton,
        &QPushButton::clicked,
        this,
        &MainWindow::stop
        );

    connect(
        previous,
        &QPushButton::clicked,
        this,
        [this]() {
            goToPage(pageSelector->value() - 2);
        }
        );

    connect(
        next,
        &QPushButton::clicked,
        this,
        [this]() {
            goToPage(pageSelector->value());
        }
        );

    connect(
        pageSelector,
        QOverload<int>::of(&QSpinBox::valueChanged),
        this,
        [this](int value) {
            goToPage(value - 1);
        }
        );

    connect(
        modeBox,
        &QComboBox::currentIndexChanged,
        this,
        [this](int) {
            stop();
            rebuildNarration();
            goToPage(startPage);
        }
        );

    connect(
        startHereButton,
        &QPushButton::clicked,
        this,
        [this]() {
            stop();

            if (pages.isEmpty())
                return;

            startPage = pageSelector->value() - 1;
            startOffset = 0;

            updateStatus(
                QString("Start set to page %1.")
                    .arg(startPage + 1)
                );
        }
        );

    connect(
        speedSlider,
        &QSlider::valueChanged,
        this,
        [this](int value) {
            speech->setRate(value / 10.0);

            speedLabel->setText(
                QString("Rate: %1")
                    .arg(value / 10.0, 0, 'f', 1)
                );
        }
        );

    pdfCanvas->onWordClicked =
        [this](int page, int position) {
            startFromWord(page, position);
        };

    pdfCanvas->onPageChanged =
        [this](int page) {
            QSignalBlocker blocker(pageSelector);

            pageSelector->setValue(page + 1);

            pageLabel->setText(
                QString("of %1")
                    .arg(document->pageCount())
                );
        };

    // Prevent an old completion from advancing
    // a newly started reading session.

    connect(
        speech,
        &QTextToSpeech::stateChanged,
        this,
        [this](QTextToSpeech::State state) {

            if (state == QTextToSpeech::Error) {
                playing = false;
                activeUtteranceId = -1;

                updateStatus(
                    "Speech error: " + speech->errorString()
                    );

                return;
            }

            if (state != QTextToSpeech::Ready
                || !playing
                || stopping
                || activeUtteranceId < 0) {
                return;
            }

            const quint64 savedSession = sessionId;

            const qsizetype savedUtterance =
                activeUtteranceId;

            QTimer::singleShot(
                0,
                this,
                [this, savedSession, savedUtterance]() {

                    if (!playing
                        || stopping
                        || sessionId != savedSession
                        || activeUtteranceId != savedUtterance
                        || speech->state()
                               != QTextToSpeech::Ready) {
                        return;
                    }

                    activeUtteranceId = -1;
                    speakNextPage();
                }
                );
        }
        );

    // Accept words only from the active utterance.

    connect(
        speech,
        &QTextToSpeech::sayingWord,
        this,
        [this](
            const QString &word,
            qsizetype id,
            qsizetype start,
            qsizetype length) {

            if (!playing
                || stopping
                || id != activeUtteranceId) {
                return;
            }

            spokenWord(word, start, length);
        }
        );

    if (!trackingAvailable) {
        updateStatus(
            "This speech engine does not support "
            "word-by-word progress."
            );
    }
}

// =====================================================
// OPEN PDF
// =====================================================

void MainWindow::openPdf()
{
    const QString path =
        QFileDialog::getOpenFileName(
            this,
            "Open PDF",
            QString(),
            "PDF Files (*.pdf)"
            );

    if (path.isEmpty())
        return;

    stop();

    pdfCanvas->setPdf(nullptr);
    document->close();

    pages.clear();
    pageLines.clear();
    narration.clear();

    if (document->load(path)
        != QPdfDocument::Error::None) {

        QMessageBox::warning(
            this,
            "SmartRead",
            "Unable to load this PDF."
            );

        return;
    }

    analyzeDocument();
    rebuildNarration();

    pdfCanvas->setPdf(document);

    pageSelector->setMaximum(
        std::max(1, document->pageCount())
        );

    setWindowTitle(
        "SmartRead - " + QFileInfo(path).fileName()
        );

    goToPage(startPage);

    if (pages.isEmpty())
        updateStatus("No extractable text found.");
}

// =====================================================
// EXTRACT PDF TEXT
// =====================================================

void MainWindow::analyzeDocument()
{
    pages.clear();
    pageLines.clear();

    for (int page = 0;
         page < document->pageCount();
         ++page) {

        const QString text =
            document->getAllText(page).text();

        pages.append(text);

        QStringList lines;

        for (const QString &line : text.split('\n')) {
            const QString trimmed = line.trimmed();

            if (!trimmed.isEmpty())
                lines.append(trimmed);
        }

        pageLines.append(lines);
    }
}

// =====================================================
// DETECT STORY START
// =====================================================

int MainWindow::detectStoryStart() const
{
    if (pages.isEmpty())
        return 0;

    const QRegularExpression prologue(
        R"(^\s*(prologue|prolog)\s*$)",
        QRegularExpression::CaseInsensitiveOption
        );

    const QRegularExpression chapter(
        R"(^\s*(chapter\s+([0-9]+|[ivxlcdm]+|[a-z]+)|part\s+([0-9]+|[ivxlcdm]+|[a-z]+))\b.*$)",
        QRegularExpression::CaseInsensitiveOption
        );

    int firstChapter = -1;

    for (int page = 0;
         page < std::min(int(pages.size()), 100);
         ++page) {

        const QStringList &lines = pageLines[page];

        for (int i = 0;
             i < std::min(int(lines.size()), 12);
             ++i) {

            if (prologue.match(lines[i]).hasMatch()
                && lines.size() > i + 2) {
                return page;
            }

            if (firstChapter < 0
                && chapter.match(lines[i]).hasMatch()
                && lines.size() > i + 2) {
                firstChapter = page;
            }
        }
    }

    return firstChapter >= 0 ? firstChapter : 0;
}

// =====================================================
// BUILD NARRATION
// =====================================================

MainWindow::NarrationPage
MainWindow::buildNarrationPage(int page) const
{
    NarrationPage result;

    if (page < 0 || page >= pages.size())
        return result;

    const QString &original = pages[page];

    // Read Everything uses the original PDF text.

    if (modeBox->currentIndex() == 1) {
        result.text = original;

        for (int i = 0; i < original.size(); ++i)
            result.sourcePositions.append(i);

        return result;
    }

    const QRegularExpression pageNumber(
        R"(^\s*(page\s+)?[0-9]{1,5}\s*$)",
        QRegularExpression::CaseInsensitiveOption
        );

    const QRegularExpression linePattern(
        R"([^\r\n]+)"
        );

    auto matches = linePattern.globalMatch(original);

    int lineIndex = 0;

    while (matches.hasNext()) {
        const auto match = matches.next();

        const QString raw = match.captured();
        const QString trimmed = raw.trimmed();

        if (trimmed.isEmpty())
            continue;

        const int currentLine = lineIndex++;

        if (pageNumber.match(trimmed).hasMatch())
            continue;

        const bool nearEdge =
            currentLine < 2
            || currentLine >= pageLines[page].size() - 2;

        bool repeated = false;

        if (nearEdge && trimmed.size() < 100) {
            int repeats = 0;

            const int first = std::max(0, page - 5);

            const int last = std::min(
                int(pageLines.size()) - 1,
                page + 5
                );

            for (int other = first;
                 other <= last;
                 ++other) {

                if (other == page)
                    continue;

                const QStringList &lines =
                    pageLines[other];

                for (int k = 0;
                     k < lines.size();
                     ++k) {

                    const bool edge =
                        k < 2
                        || k >= lines.size() - 2;

                    if (edge
                        && lines[k].compare(
                               trimmed,
                               Qt::CaseInsensitive
                               ) == 0) {

                        ++repeats;
                        break;
                    }
                }
            }

            repeated = repeats >= 2;
        }

        if (repeated)
            continue;

        // Insert a space between extracted lines.
        if (!result.text.isEmpty()) {
            result.text.append(' ');
            result.sourcePositions.append(-1);
        }

        const int rawStart =
            int(match.capturedStart());

        int firstCharacter = 0;

        while (firstCharacter < raw.size()
               && raw[firstCharacter].isSpace()) {
            ++firstCharacter;
        }

        for (int i = 0; i < trimmed.size(); ++i) {
            result.text.append(trimmed[i]);

            result.sourcePositions.append(
                rawStart + firstCharacter + i
                );
        }
    }

    return result;
}

// =====================================================
// REBUILD NARRATION
// =====================================================

void MainWindow::rebuildNarration()
{
    narration.clear();

    if (pages.isEmpty())
        return;

    startPage =
        modeBox->currentIndex() == 0
            ? detectStoryStart()
            : 0;

    startOffset = 0;

    for (int page = 0; page < pages.size(); ++page) {
        narration.append(buildNarrationPage(page));
    }

    nextPage = startPage;

    updateStatus(
        QString("Ready. Start page: %1.")
            .arg(startPage + 1)
        );
}

// =====================================================
// PLAYBACK
// =====================================================

void MainWindow::play()
{
    if (narration.isEmpty())
        return;

    if (speech->state() == QTextToSpeech::Paused) {
        resume();
        return;
    }

    stop();

    playing = true;
    stopping = false;

    nextPage = startPage;
    speechOffset = startOffset;

    speakNextPage();
}

void MainWindow::pause()
{
    if (speech->state() == QTextToSpeech::Speaking) {
        speech->pause();
        updateStatus("Paused.");
    }
}

void MainWindow::resume()
{
    if (speech->state() == QTextToSpeech::Paused) {
        speech->resume();
        updateStatus("Resumed.");
    }
}

void MainWindow::stop()
{
    stopping = true;
    playing = false;

    // Invalidate all earlier playback callbacks.
    ++sessionId;
    activeUtteranceId = -1;

    speech->stop(
        QTextToSpeech::BoundaryHint::Immediate
        );

    currentPage = -1;

    if (pdfCanvas)
        pdfCanvas->clearHighlight();

    if (wordLabel)
        wordLabel->setText("Current word: --");

    stopping = false;
    updateStatus("Stopped.");
}

// =====================================================
// SPEAK NEXT PAGE
// =====================================================

void MainWindow::speakNextPage()
{
    if (!playing)
        return;

    while (nextPage < narration.size()) {
        const int page = nextPage++;

        const NarrationPage &entry = narration[page];

        int offset = std::clamp(
            speechOffset,
            0,
            int(entry.text.size())
            );

        speechOffset = 0;

        while (offset < entry.text.size()
               && entry.text[offset].isSpace()) {
            ++offset;
        }

        if (offset >= entry.text.size())
            continue;

        currentPage = page;
        speechOffset = offset;

        // Avoid jumping to the top of the same page.
        if (page != pageSelector->value() - 1)
            goToPage(page);

        updateStatus(
            QString("Reading page %1 of %2")
                .arg(page + 1)
                .arg(narration.size())
            );

        const QString utterance =
            entry.text.mid(offset);

        const quint64 savedSession = sessionId;

        // Wait until the previous stop settles.
        QTimer::singleShot(
            0,
            this,
            [this, utterance, savedSession, page]() {

                if (!playing
                    || stopping
                    || sessionId != savedSession
                    || currentPage != page) {
                    return;
                }

                // Store the ID returned by Qt.
                activeUtteranceId =
                    speech->enqueue(utterance);

                if (activeUtteranceId < 0) {
                    playing = false;

                    updateStatus(
                        "Could not begin speaking."
                        );
                }
            }
            );

        return;
    }

    playing = false;
    activeUtteranceId = -1;
    currentPage = -1;

    pdfCanvas->clearHighlight();
    updateStatus("Finished reading.");
}

// =====================================================
// CLICK TO READ
// =====================================================

void MainWindow::startFromWord(
    int page,
    int sourcePosition)
{
    if (page < 0 || page >= narration.size())
        return;

    const NarrationPage &entry = narration[page];

    int offset = -1;

    for (int i = 0;
         i < entry.sourcePositions.size();
         ++i) {

        if (entry.sourcePositions[i] >= sourcePosition) {
            offset = i;
            break;
        }
    }

    // Fall back to the next readable page.
    if (offset < 0) {
        for (int p = page + 1;
             p < narration.size();
             ++p) {

            if (!narration[p].text.trimmed().isEmpty()) {
                page = p;
                offset = 0;
                break;
            }
        }
    }

    if (offset < 0)
        return;

    const int beginning =
        wordStart(narration[page].text, offset);

    if (beginning >= 0)
        offset = beginning;

    stop();

    startPage = page;
    startOffset = offset;

    playing = true;
    stopping = false;

    nextPage = startPage;
    speechOffset = startOffset;

    speakNextPage();
}

// =====================================================
// SPOKEN WORD HIGHLIGHTING
// =====================================================

void MainWindow::spokenWord(
    const QString &word,
    qsizetype start,
    qsizetype length)
{
    Q_UNUSED(word);
    Q_UNUSED(length);

    if (!playing
        || currentPage < 0
        || currentPage >= narration.size()) {
        return;
    }

    const NarrationPage &entry =
        narration[currentPage];

    const int spokenIndex =
        speechOffset + int(start);

    if (spokenIndex < 0
        || spokenIndex >= entry.sourcePositions.size()) {
        return;
    }

    int sourceIndex = -1;

    for (int i = spokenIndex;
         i < entry.sourcePositions.size();
         ++i) {

        if (entry.sourcePositions[i] >= 0) {
            sourceIndex = entry.sourcePositions[i];
            break;
        }
    }

    if (sourceIndex < 0)
        return;

    const QString &source = pages[currentPage];

    const int begin =
        wordStart(source, sourceIndex);

    if (begin < 0)
        return;

    const int end =
        wordEnd(source, begin);

    if (end <= begin)
        return;

    wordLabel->setText(
        "Current word: "
        + source.mid(begin, end - begin)
        );

    pdfCanvas->setHighlight(
        currentPage,
        begin,
        end - begin
        );
}

// =====================================================
// PAGE NAVIGATION
// =====================================================

void MainWindow::goToPage(int page)
{
    if (!document || document->pageCount() == 0)
        return;

    page = std::clamp(
        page,
        0,
        document->pageCount() - 1
        );

    pdfCanvas->goToPage(page);

    QSignalBlocker blocker(pageSelector);

    pageSelector->setValue(page + 1);

    pageLabel->setText(
        QString("of %1")
            .arg(document->pageCount())
        );
}

// =====================================================
// STATUS
// =====================================================

void MainWindow::updateStatus(const QString &message)
{
    if (statusLabel)
        statusLabel->setText(message);
}
